enum class GeneroMusica {
    Rock, Pop, Heavy, Rap, Jazz
}