class Pelicula: Producto() {
    protected var Genero: GeneroPelicula = GeneroPelicula.Comedia
    protected var Director: String = ""
}