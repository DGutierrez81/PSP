enum class GeneroPelicula {
    Terror, Comedia, Accion, Suspense
}