class Disco: Producto() {
    protected var Genero: GeneroMusica = GeneroMusica.Rock
    protected var Grupo: String = ""
    protected var Stock: Int = 0
}