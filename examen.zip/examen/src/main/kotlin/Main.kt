fun main(args: Array<String>){
    var pelicula = Pelicula()

    println(pelicula.obtenerTitulo())
}